#!/usr/bin/env python
# coding: utf-8

#  _________________________________________________________
# # K_MEANS_ASSIGNMENT
# __________________________________________________________
#
# ## Student number: 3838305
# _________________________________________________________
#
# ### Task 1
# _________________________________________________________

# In[4]:


# Libaries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

get_ipython().run_line_magic("matplotlib", "inline")


class k_means:

    col = {
        1: "lime",
        2: "black",
        3: "blue",
        4: "red",
        5: "m",
        6: "c",
        7: "brown",
        8: "deeppink",
        9: "g",
    }  # colours for the different clusters
    shapes = {
        1: "X",
        2: "*",
        3: "h",
        4: "P",
        5: "D",
        6: "d",
        7: "s",
        8: "h",
        9: "^",
    }  # symbols for the centroids
    size = 90  # size for the centroids

    def __init__(self, filename, k, MaxIters):
        self.df = pd.read_csv(filename, header=None)  # data is loaded in a dataframe
        self.k = k  # number of clusters
        self.MaxIters = MaxIters  # limit of iterations
        self.run()  # call run() method

        # calculate distance and assign the 4 closest points to the clustered centers

    def assign(self, df, centroids):
        for i in centroids.keys():
            # sqrt((x1-x2)^2 - (y1-y1)^2)
            df[f"distance_from_{i}"] = np.sqrt(
                ((df[0] - centroids[i][0]) ** 2) + ((df[1] - centroids[i][1]) ** 2)
            )  # calculates the distance from all points

        centroid_distance_cols = [
            f"distance_from_{i}" for i in centroids.keys()
        ]  # stores every distance from each centroid
        df["closest"] = df.loc[:, centroid_distance_cols].idxmin(
            axis=1
        )  # takes the minimum distance
        df["closest"] = df["closest"].map(
            lambda x: int(x.lstrip("distance_from_"))
        )  # takes the (i), the centroid number it is closest to
        df["color"] = df["closest"].map(
            lambda x: self.col[x]
        )  # colour is taken from list
        return df

    def update(self, centroids):
        for i in self.centroids.keys():
            self.centroids[i][0] = np.mean(
                self.df[self.df["closest"] == i][0]
            )  # mean of the closest x points
            self.centroids[i][1] = np.mean(
                self.df[self.df["closest"] == i][1]
            )  # mean of the closest y points
        return centroids

    def run(self):
        self.centroids = {
            i
            + 1: [
                np.random.randint(0, 4000000),
                np.random.randint(0, 4000000),
            ]  # generate random points
            for i in range(self.k)
        }
        self.df = self.assign(self.df, self.centroids)  # call assign() method
        self.centroids = self.update(self.centroids)  # call update() method

        change = False
        iters = 0

        while (change != True) and (iters <= self.MaxIters):
            closest_centroids = self.df["closest"].copy(
                deep=True
            )  # copy previous centroids
            self.centroids = self.update(self.centroids)  # call update() method
            self.df = self.assign(self.df, self.centroids)  # call assign() method
            if closest_centroids.equals(
                self.df["closest"]
            ):  # previous centroid = current centroid
                change = True
                break
        iters += 1

    def plots(self):

        fig = plt.figure(figsize=(14, 14))  # size of the diagram
        plt.scatter(
            self.df[0],
            self.df[1],
            s=50,
            alpha=0.5,
            color=self.df["color"],
            edgecolor="k",
        )  # scatter points
        for i in self.centroids.keys():
            plt.scatter(
                *self.centroids[i],
                s=self.size,
                color=self.col[i],
                marker=self.shapes[i],
            )  # scatter centroids
        plt.title("K-Means Cluster")
        plt.xlabel("X")
        plt.ylabel("Y")
        plt.xlim(0, 4000000)  # x axis size
        plt.ylim(0, 4000000)  # y axis size
        plt.show()
        print(f"Centroids:\n{self.centroids}\n")  # prints centroids


# ____________________________________________________________________________________________________________________________
# ### Task 2
# ____________________________________________________________________________________________________________________________

# In[5]:


#!usr/bin/python3

import random

studentno = int(
    input("Please enter your student number: ")
)  # My student number: 3838305
random.seed(studentno % 10000)
col1 = [random.randint(0, studentno) for i in range(0, 200)]
random.seed(studentno % 1000)
col2 = [random.randint(0, studentno) for i in range(0, 200)]
sdata = open("data.txt", mode="w")
[print("%s, %s" % (str(col1[i]), str(col2[i])), file=sdata) for i in range(0, 200)]
sdata.close()


# In[6]:


kmeans_dataplot = k_means("data.txt", 4, 300)
kmeans_dataplot.plots()


# In[50]:


sdata = open("data.txt", mode="r")
data = sdata.read()
df = pd.read_csv("data.txt", header=None)
print(f"{df}\n", f"\n{data}")  # prints the coordinates
sdata.close()


# ____________________________________________________________________________________________________________________________
# ### Task 3
# ____________________________________________________________________________________________________________________________

# Pandas DataFrame is easier to manipulate and analyze with this particular amount of data, therefore I decided to use pandas, with the implimentaion of classes in order to create objects which is better to analyse the data if theres multiple objects.
#
# "Col", "shapes" and "size" is initialised. "col" has a list with colours assigned to numbers 1 through 9 that will be used for the different clusters. The "shapes" has a list of symbols that is assigned to numbers 1 through 9 that will be used to differentiate the centroids. "Size" will be used to make the centroids larger than the other points.
#
# Then Initalizing "df" to read in the data file, "k", "Maxiters", and "run()" method to call the method run
#
# With the class named "k_means()" and 4 methods being used:
#
# "assign()" which takes in 2parameters of "df" and "centroids", with the implimentation of a for loop to calculate the distance from all points of the centroids (ecildean distance).
#
# "update()" which takes in 1parameters of "centroids", with the implimentation of a for loop to calculate the the mean of the closest points of the centroids
#
# "run()" which takes no parameters. It randomly generates points with the implementation of a for loop in the range of "k (which are the number of clusters)". "Iters" is then initialised for the while loop as well as "change = False" in order to check the condition as the loop runs and will break out of the loop when "change = True" and "iters <= MaxIters". The centroids will continuously be updating in this loop with the "update()" and "assign()" functions until the loop ends. The while loop will end when Iters equals 300 which is when "iters <= MaxIters" or when the previous centroid equals the present centroid then "change = True" and will brak out of the loop, and then it will call the function plots() before the while loop ends. The data is then plotted on the diagram.
#
# "plots()" which takes no parameters, and plots all the points.
# ___________________________________________________________________________________________________________________________
# ___________________________________________________________________________________________________________________________
# class k_means only accepts 3 arguments; the filename called "data.txt", number of clusters called "k" and the maximum iteration called "MaxIters". It calls on the "run()" method, where k random points are generated for the centroids and stores them as a list.
# The method "assign()" is called to calculate the distance from the points to every centroid and stores them with the centroid number it is closest to with the colour assigned to that number. The  "update()" is called to calculate the mean of the closest points.
# Then the method called "plot()" plots the data with the clusters being a different colour according to the centroid and the centroids are differentiated with different colour and shape.
# ___________________________________________________________________________________________________________________________
#
# Note: Comments have also been included in the code in order to explain what certain lines do.
# ___________________________________________________________________________________________________________________________

# ____________________________________________________________________________________________________________________________
# ### Task 4
# ____________________________________________________________________________________________________________________________

# The Elbow method is used to determine or validate the optimal number of clusters in a data set that data can be clustered in to. This method works best if data is much clustered.
# It uses the Euclidean distance metric to calculate the mean of the squared distances from the center of the clusters of respective clusters.
# The values are plotted on a line chart that resembles an arm and plotting the "elbow" curves as the number of clusters to use. This will be the point where the value of a specified number of clusters at which improvement in distortion declines the most and data should not be further divided into clusters as the plots starts to become linear.
#
# EG: k(number of cluster) = 4
#

# In[8]:


# Elbow method implementation
import pandas as pd

df = pd.read_csv("data.txt", header=None)
import matplotlib.pyplot as plt

get_ipython().run_line_magic("matplotlib", "inline")
from sklearn import cluster

numClusters = range(1, 10)
SSE = []
for k in numClusters:
    k_means = cluster.KMeans(n_clusters=k)
    k_means.fit(df)
    SSE.append(k_means.inertia_)

fig = plt.figure(figsize=(8, 5))
plt.plot(numClusters, SSE)
plt.xlabel("Number of Clusters")
plt.ylabel("SSE")
(f"SSE: {SSE}")


# In[ ]:
